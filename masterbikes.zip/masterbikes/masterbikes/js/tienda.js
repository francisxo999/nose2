// Datos de ejemplo para la tienda
const bikeInventory = [
    {
        id: 1,
        name: "Montaña Pro 29\"",
        category: "montaña",
        price: 450000,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        description: "Bicicleta todo terreno con suspensión delantera",
        stock: 5
    },
    {
        id: 2,
        name: "Urbana Elegance",
        category: "urbana",
        price: 320000,
        rating: 4.2,
        image: "https://images.unsplash.com/photo-1511994298241-608e28f14fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        description: "Diseño clásico para la ciudad",
        stock: 8
    },
    {
        id: 3,
        name: "Ruta Velocity",
        category: "ruta",
        price: 580000,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        description: "Alto rendimiento para carretera",
        stock: 3
    },
    // Más bicicletas...
];

document.addEventListener('DOMContentLoaded', function() {
    const bikeGrid = document.getElementById('bike-grid');
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const categoryFilter = document.getElementById('category-filter');
    const priceFilter = document.getElementById('price-filter');
    const ratingFilter = document.getElementById('rating-filter');

    // Cargar bicicletas al iniciar
    renderBikes(bikeInventory);

    // Event listeners para filtros
    searchBtn.addEventListener('click', filterBikes);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') filterBikes();
    });
    categoryFilter.addEventListener('change', filterBikes);
    priceFilter.addEventListener('change', filterBikes);
    ratingFilter.addEventListener('change', filterBikes);

    function filterBikes() {
        const searchTerm = searchInput.value.toLowerCase();
        const category = categoryFilter.value;
        const priceRange = priceFilter.value;
        const minRating = ratingFilter.value;

        const filteredBikes = bikeInventory.filter(bike => {
            // Filtro por búsqueda
            const matchesSearch = bike.name.toLowerCase().includes(searchTerm) || 
                                 bike.description.toLowerCase().includes(searchTerm);
            
            // Filtro por categoría
            const matchesCategory = !category || bike.category === category;
            
            // Filtro por precio
            let matchesPrice = true;
            if (priceRange) {
                const [min, max] = priceRange.split('-').map(Number);
                if (max) {
                    matchesPrice = bike.price >= min && bike.price <= max;
                } else {
                    matchesPrice = bike.price >= min;
                }
            }
            
            // Filtro por rating
            const matchesRating = !minRating || bike.rating >= Number(minRating);
            
            return matchesSearch && matchesCategory && matchesPrice && matchesRating;
        });

        renderBikes(filteredBikes);
    }

    function renderBikes(bikes) {
        bikeGrid.innerHTML = '';
        
        if (bikes.length === 0) {
            bikeGrid.innerHTML = '<p class="no-results">No se encontraron bicicletas que coincidan con los filtros.</p>';
            return;
        }
        
        bikes.forEach(bike => {
            const bikeCard = document.createElement('div');
            bikeCard.className = 'bike-card';
            
            bikeCard.innerHTML = `
                <div class="bike-img" style="background-image: url('${bike.image}')"></div>
                <div class="bike-info">
                    <h3>${bike.name}</h3>
                    <p>${bike.description}</p>
                    <div class="bike-meta">
                        <span class="bike-category">${getCategoryName(bike.category)}</span>
                        <span class="bike-rating">${renderStars(bike.rating)}</span>
                    </div>
                    <div class="bike-price">$${bike.price.toLocaleString('es-CL')}</div>
                    <div class="bike-stock">Disponibles: ${bike.stock}</div>
                    <div class="bike-actions">
                        <a href="#" class="btn btn-outline">Detalles</a>
                        <a href="#" class="btn btn-solid" data-bike-id="${bike.id}">Comprar</a>
                    </div>
                </div>
            `;
            
            bikeGrid.appendChild(bikeCard);
        });
    }

    function getCategoryName(category) {
        const categories = {
            'montaña': 'Montaña',
            'urbana': 'Urbana',
            'ruta': 'Ruta',
            'infantil': 'Infantil'
        };
        return categories[category] || category;
    }

    function renderStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        let stars = '';
        
        for (let i = 0; i < fullStars; i++) {
            stars += '<i class="fas fa-star"></i>';
        }
        
        if (hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        }
        
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        for (let i = 0; i < emptyStars; i++) {
            stars += '<i class="far fa-star"></i>';
        }
        
        return stars;
    }
});