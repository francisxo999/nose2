// Cuenta demo preconfigurada
const demoAccount = {
    email: "tester@masterbikes.cl",
    password: "MasterBikes2025",
    name: "Usuario Demo"
};

// Variables para el proceso de registro
let generatedCode = "";
let registeredUsers = [demoAccount];
let currentUser = null;

// Función para verificar si estamos en la página de login
function isLoginPage() {
    return window.location.pathname.includes('login.html');
}

// Función para mostrar/ocultar elementos según el estado de autenticación
function updateAuthUI() {
    if (isLoginPage()) return;
    
    const authButtons = document.getElementById('auth-buttons');
    const userProfile = document.getElementById('user-profile');
    
    if (currentUser) {
        if (authButtons) authButtons.style.display = 'none';
        if (userProfile) {
            userProfile.style.display = 'flex';
            document.getElementById('user-name').textContent = currentUser.name;
            document.getElementById('user-avatar').textContent = currentUser.name.charAt(0).toUpperCase();
        }
    } else {
        if (authButtons) authButtons.style.display = 'block';
        if (userProfile) userProfile.style.display = 'none';
    }
}

// Validar email
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Mostrar/ocultar mensajes de error
function showError(elementId, show, message = '') {
    const element = document.getElementById(elementId);
    if (message) element.textContent = message;
    element.style.display = show ? 'block' : 'none';
}

// Función de login
function login() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    let valid = true;
    
    // Validar email
    if (!email || !isValidEmail(email)) {
        showError('login-email-error', true);
        valid = false;
    } else {
        showError('login-email-error', false);
    }
    
    // Validar contraseña
    if (!password) {
        showError('login-password-error', true);
        valid = false;
    } else {
        showError('login-password-error', false);
    }
    
    if (!valid) return;
    
    // Verificar credenciales
    const user = registeredUsers.find(u => u.email === email && u.password === password);
    
    if (user) {
        // Login exitoso
        showError('login-general-error', false);
        currentUser = user;
        
        // Guardar en localStorage (simulación de sesión)
        localStorage.setItem('currentUser', JSON.stringify(user));
        
        // Redirigir a la página principal si estamos en login
        if (isLoginPage()) {
            window.location.href = 'index.html';
        } else {
            updateAuthUI();
        }
    } else {
        showError('login-general-error', true, 'Correo o contraseña incorrectos');
    }
}

// Función de logout
function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    updateAuthUI();
    
    // Si estamos en una página privada, redirigir al inicio
    if (!isLoginPage()) {
        window.location.href = 'index.html';
    }
}

// Iniciar proceso de registro
function startRegistration() {
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirm = document.getElementById('register-confirm').value;
    let valid = true;
    
    // Validar nombre
    if (!name) {
        showError('register-name-error', true);
        valid = false;
    } else {
        showError('register-name-error', false);
    }
    
    // Validar email
    if (!email || !isValidEmail(email)) {
        showError('register-email-error', true, 'Por favor ingresa un correo válido');
        valid = false;
    } else if (registeredUsers.some(u => u.email === email)) {
        showError('register-email-error', true, 'Este correo ya está registrado');
        valid = false;
    } else {
        showError('register-email-error', false);
    }
    
    // Validar contraseña
    if (!password || password.length < 6) {
        showError('register-password-error', true);
        valid = false;
    } else {
        showError('register-password-error', false);
    }
    
    // Validar confirmación
    if (password !== confirm) {
        showError('register-confirm-error', true);
        valid = false;
    } else {
        showError('register-confirm-error', false);
    }
    
    if (!valid) return;
    
    // Generar código de verificación (simulado)
    generatedCode = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Mostrar sección de verificación
    document.getElementById('verification-code-group').style.display = 'block';
    document.getElementById('register-submit').style.display = 'none';
    document.getElementById('verify-btn').style.display = 'block';
    
    // Simular envío de código por email
    alert(`Se ha enviado un código de verificación a ${email}\n\nCódigo generado (simulación): ${generatedCode}\n\nEn un sistema real, esto se enviaría por email.`);
}

// Verificar código de registro
function verifyCode() {
    const code = document.getElementById('verification-code').value;
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    
    if (code === generatedCode) {
        // Registro exitoso
        showError('verification-code-error', false);
        document.getElementById('verification-success').style.display = 'block';
        
        // Agregar usuario (en memoria, en un sistema real se enviaría al backend)
        const newUser = { name, email, password };
        registeredUsers.push(newUser);
        
        // Mostrar mensaje de éxito
        document.getElementById('register-success').textContent = '¡Registro completado con éxito!';
        document.getElementById('register-success').style.display = 'block';
        
        // Auto-login después de registro
        setTimeout(() => {
            currentUser = newUser;
            localStorage.setItem('currentUser', JSON.stringify(newUser));
            window.location.href = 'index.html';
        }, 1500);
    } else {
        showError('verification-code-error', true);
    }
}

// Cambiar entre pestañas de login y registro
function switchTab(tab) {
    const loginTab = document.getElementById('login-tab');
    const registerTab = document.getElementById('register-tab');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    if (!loginTab || !registerTab || !loginForm || !registerForm) return;
    
    loginTab.classList.remove('active');
    registerTab.classList.remove('active');
    loginForm.classList.remove('active');
    registerForm.classList.remove('active');
    
    if (tab === 'login') {
        loginTab.classList.add('active');
        loginForm.classList.add('active');
        if (document.getElementById('auth-modal-title')) {
            document.getElementById('auth-modal-title').textContent = 'Acceso a tu cuenta';
        }
    } else {
        registerTab.classList.add('active');
        registerForm.classList.add('active');
        if (document.getElementById('auth-modal-title')) {
            document.getElementById('auth-modal-title').textContent = 'Crear nueva cuenta';
        }
    }
}

// Inicialización cuando el DOM está listo
document.addEventListener('DOMContentLoaded', () => {
    // Verificar si hay un usuario en localStorage
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
    }
    
    // Actualizar UI según autenticación
    updateAuthUI();
    
    // Configurar eventos para la página de login
    if (isLoginPage()) {
        // Tabs del formulario
        const loginTab = document.getElementById('login-tab');
        const registerTab = document.getElementById('register-tab');
        
        if (loginTab && registerTab) {
            loginTab.addEventListener('click', () => switchTab('login'));
            registerTab.addEventListener('click', () => switchTab('register'));
        }
        
        // Formulario de login
        const loginSubmit = document.getElementById('login-submit');
        if (loginSubmit) {
            loginSubmit.addEventListener('click', login);
        }
        
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') login();
            });
        }
        
        // Formulario de registro
        const registerSubmit = document.getElementById('register-submit');
        if (registerSubmit) {
            registerSubmit.addEventListener('click', startRegistration);
        }
        
        const verifyBtn = document.getElementById('verify-btn');
        if (verifyBtn) {
            verifyBtn.addEventListener('click', verifyCode);
        }
        
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    if (document.getElementById('verify-btn').style.display === 'block') {
                        verifyCode();
                    } else {
                        startRegistration();
                    }
                }
            });
        }
        
        // Rellenar datos demo automáticamente al hacer clic en el tab de login
        if (loginTab) {
            loginTab.addEventListener('click', function() {
                const loginEmail = document.getElementById('login-email');
                const loginPassword = document.getElementById('login-password');
                if (loginEmail && loginPassword) {
                    loginEmail.value = demoAccount.email;
                    loginPassword.value = demoAccount.password;
                }
            });
        }
    } else {
        // Configurar eventos para la página principal
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', logout);
        }
    }
});