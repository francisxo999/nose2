document.addEventListener('DOMContentLoaded', function() {
    const repairForm = document.getElementById('repair-request-form');
    
    repairForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('repair-name').value;
        const email = document.getElementById('repair-email').value;
        const phone = document.getElementById('repair-phone').value;
        const bikeType = document.getElementById('repair-bike-type').value;
        const date = document.getElementById('repair-date').value;
        const problem = document.getElementById('repair-problem').value;
        const urgency = document.getElementById('repair-urgency').value;
        
        if (!name || !email || !phone || !bikeType || !date || !problem) {
            alert('Por favor complete todos los campos requeridos');
            return;
        }
        
        // Validar email
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            alert('Por favor ingrese un correo electrónico válido');
            return;
        }
        
        // Validar fecha (no puede ser anterior a hoy)
        const today = new Date().toISOString().split('T')[0];
        if (date < today) {
            alert('La fecha de reparación no puede ser anterior al día de hoy');
            return;
        }
        
        // Aquí normalmente enviaríamos la solicitud al servidor
        alert(`Solicitud de reparación enviada:\n\nNombre: ${name}\nEmail: ${email}\nTeléfono: ${phone}\nTipo de bicicleta: ${bikeType}\nFecha preferente: ${date}\nUrgencia: ${urgency}\n\nProblema:\n${problem}\n\nGracias por su solicitud. Nos pondremos en contacto con usted para confirmar.`);
        
        // Limpiar el formulario
        repairForm.reset();
    });
    
    // Establecer fecha mínima como hoy
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('repair-date').min = today;
});