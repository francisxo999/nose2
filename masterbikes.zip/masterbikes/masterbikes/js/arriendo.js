// Datos de ejemplo para arriendo
const rentalBikes = [
    {
        id: 1,
        name: "Montaña Trail XT",
        image: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        description: "Perfecta para senderos de montaña",
        dailyRate: 20000,
        weeklyRate: 100000,
        hourlyRate: 5000,
        available: true,
        bookedDates: []
    },
    {
        id: 2,
        name: "Urbana Comfort",
        image: "https://images.unsplash.com/photo-1511994298241-608e28f14fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        description: "Cómoda para la ciudad",
        dailyRate: 15000,
        weeklyRate: 80000,
        hourlyRate: 4000,
        available: true,
        bookedDates: []
    },
    // Más bicicletas para arriendo...
];

document.addEventListener('DOMContentLoaded', function() {
    const rentalBikeGrid = document.getElementById('rental-bike-grid');
    const dateFilter = document.getElementById('date-filter');
    const checkAvailabilityBtn = document.getElementById('check-availability');
    const rentalForm = document.getElementById('rental-form');
    const rentalRequestForm = document.getElementById('rental-request-form');
    const cancelRentalBtn = document.getElementById('cancel-rental');
    
    let selectedBike = null;
    
    // Establecer fecha mínima como hoy
    const today = new Date().toISOString().split('T')[0];
    dateFilter.min = today;
    
    // Cargar bicicletas disponibles
    renderRentalBikes(rentalBikes);
    
    // Event listeners
    checkAvailabilityBtn.addEventListener('click', checkAvailability);
    cancelRentalBtn.addEventListener('click', cancelRental);
    rentalRequestForm.addEventListener('submit', submitRentalRequest);
    
    function checkAvailability() {
        const selectedDate = dateFilter.value;
        
        if (!selectedDate) {
            alert('Por favor seleccione una fecha para ver disponibilidad');
            return;
        }
        
        const filteredBikes = rentalBikes.filter(bike => {
            // Verificar si la bicicleta está disponible en general
            if (!bike.available) return false;
            
            // Verificar si la bicicleta está reservada para la fecha seleccionada
            const isBooked = bike.bookedDates.some(date => date === selectedDate);
            return !isBooked;
        });
        
        renderRentalBikes(filteredBikes);
    }
    
    function renderRentalBikes(bikes) {
        rentalBikeGrid.innerHTML = '';
        
        if (bikes.length === 0) {
            rentalBikeGrid.innerHTML = '<p class="no-results">No hay bicicletas disponibles para la fecha seleccionada.</p>';
            return;
        }
        
        bikes.forEach(bike => {
            const bikeCard = document.createElement('div');
            bikeCard.className = 'bike-card rental-bike';
            
            bikeCard.innerHTML = `
                <div class="bike-img" style="background-image: url('${bike.image}')"></div>
                <div class="bike-info">
                    <h3>${bike.name}</h3>
                    <p>${bike.description}</p>
                    <div class="bike-rates">
                        <div><i class="fas fa-clock"></i> $${bike.hourlyRate.toLocaleString('es-CL')}/hora</div>
                        <div><i class="fas fa-calendar-day"></i> $${bike.dailyRate.toLocaleString('es-CL')}/día</div>
                        <div><i class="fas fa-calendar-week"></i> $${bike.weeklyRate.toLocaleString('es-CL')}/semana</div>
                    </div>
                    <div class="bike-actions">
                        <button class="btn btn-solid rent-btn" data-bike-id="${bike.id}">Arrendar</button>
                    </div>
                </div>
            `;
            
            rentalBikeGrid.appendChild(bikeCard);
        });
        
        // Agregar event listeners a los botones de arriendo
        document.querySelectorAll('.rent-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const bikeId = parseInt(this.getAttribute('data-bike-id'));
                selectedBike = rentalBikes.find(bike => bike.id === bikeId);
                showRentalForm(selectedBike);
            });
        });
    }
    
    function showRentalForm(bike) {
        document.getElementById('rental-bike-model').value = bike.name;
        
        // Establecer fecha mínima para el formulario
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('rental-start-date').min = today;
        document.getElementById('rental-end-date').min = today;
        
        // Ocultar la cuadrícula y mostrar el formulario
        rentalBikeGrid.style.display = 'none';
        rentalForm.style.display = 'block';
    }
    
    function cancelRental() {
        // Mostrar la cuadrícula y ocultar el formulario
        rentalBikeGrid.style.display = 'grid';
        rentalForm.style.display = 'none';
        selectedBike = null;
    }
    
    function submitRentalRequest(e) {
        e.preventDefault();
        
        if (!selectedBike) {
            alert('Error: No se ha seleccionado una bicicleta');
            return;
        }
        
        const startDate = document.getElementById('rental-start-date').value;
        const endDate = document.getElementById('rental-end-date').value;
        const plan = document.getElementById('rental-plan').value;
        const notes = document.getElementById('rental-notes').value;
        
        if (!startDate || !endDate || !plan) {
            alert('Por favor complete todos los campos requeridos');
            return;
        }
        
        // Validar fechas
        if (new Date(endDate) < new Date(startDate)) {
            alert('La fecha de término debe ser posterior a la fecha de inicio');
            return;
        }
        
        // Aquí normalmente enviaríamos la solicitud al servidor
        alert(`Solicitud de arriendo enviada:\n\nBicicleta: ${selectedBike.name}\nPlan: ${plan}\nDesde: ${startDate}\nHasta: ${endDate}\n\nGracias por su solicitud. Nos pondremos en contacto con usted para confirmar.`);
        
        // Limpiar el formulario
        rentalRequestForm.reset();
        cancelRental();
    }
});